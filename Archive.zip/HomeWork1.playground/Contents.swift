//: Playground - noun: a place where people can play

import UIKit

var name: String = "Yura"
var lastName: String = "Petrov"
var age: Int = 24
var height: Double = 181.5
var weight: Float = 76.5